#!/usr/bin/env python

from distutils.core import setup


setup(
    name="Attention", 
    version="0.1",
    author="Mark Rabins",
    description="A small package for Mark",
    packages=['Attention'],
    requires=['tensorflow']
)
